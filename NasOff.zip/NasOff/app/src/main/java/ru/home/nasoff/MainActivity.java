package ru.home.nasoff;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.view.View;
import android.widget.TextView;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Одна большая кнопка: штатное выключение Verbatim NAS через его веб-интерфейс.
 *
 * Прошивка NAS (1.0.3.1) не требует авторизации на CGI-страницах, поэтому
 * достаточно POST с полем powerAction=2 на /cgi/power/powerHandler.cgi.
 * Значение 1 в этой прошивке означает перезагрузку, 2 — выключение.
 */
public class MainActivity extends Activity {

    /** Адрес NAS. При смене IP править здесь. */
    private static final String HOST = "192.168.1.108";
    private static final String OFF_URL = "http://" + HOST + "/cgi/power/powerHandler.cgi";

    /** Порт для проверки доступности (SMB). */
    private static final int TCP_PORT = 445;
    private static final int CONNECT_TIMEOUT_MS = 1200;

    private TextView statusView;
    private TextView hintView;
    private View powerButton;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile boolean busy = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusView = (TextView) findViewById(R.id.txtStatus);
        hintView = (TextView) findViewById(R.id.txtHint);
        powerButton = findViewById(R.id.btnPower);

        powerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmAndShutdown();
            }
        });

        refreshStatusAsync();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!busy) {
            refreshStatusAsync();
        }
    }

    private void setStatus(final String text) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                statusView.setText(text);
            }
        });
    }

    private boolean isNasOnline() {
        Socket socket = new Socket();
        try {
            socket.connect(new InetSocketAddress(HOST, TCP_PORT), CONNECT_TIMEOUT_MS);
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            try {
                socket.close();
            } catch (Exception ignored) {
            }
        }
    }

    private void refreshStatusAsync() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                boolean online = isNasOnline();
                setStatus(online ? "NAS включён" : "NAS выключен");
            }
        }).start();
    }

    private void confirmAndShutdown() {
        if (busy) {
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Выключить NAS?")
                .setMessage("Штатное выключение займёт несколько секунд.\nДиск будет размонтирован корректно.")
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Выключить", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        shutdown();
                    }
                })
                .show();
    }

    private void vibrate() {
        try {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v != null) {
                v.vibrate(80);
            }
        } catch (Exception ignored) {
        }
    }

    private void shutdown() {
        busy = true;
        ui.post(new Runnable() {
            @Override
            public void run() {
                powerButton.setEnabled(false);
                statusView.setText("отправляю команду…");
                hintView.setText("Ждём, пока NAS выключится…");
            }
        });
        vibrate();

        new Thread(new Runnable() {
            @Override
            public void run() {
                String error = null;
                HttpURLConnection conn = null;
                try {
                    URL url = new URL(OFF_URL);
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setConnectTimeout(4000);
                    conn.setReadTimeout(4000);
                    conn.setDoOutput(true);
                    conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                    byte[] body = "powerAction=2".getBytes(StandardCharsets.UTF_8);
                    conn.setFixedLengthStreamingMode(body.length);
                    OutputStream os = conn.getOutputStream();
                    os.write(body);
                    os.flush();
                    os.close();

                    int code = conn.getResponseCode();
                    if (code != 200 && code != 201 && code != 204) {
                        error = "NAS ответил кодом " + code;
                    }
                } catch (Exception e) {
                    error = "Не удалось связаться с NAS: " + e.getClass().getSimpleName();
                } finally {
                    if (conn != null) {
                        conn.disconnect();
                    }
                }

                if (error != null) {
                    final String message = error;
                    busy = false;
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            powerButton.setEnabled(true);
                            statusView.setText("ошибка");
                            hintView.setText(message);
                        }
                    });
                    return;
                }

                // ждём, пока устройство пропадёт из сети (до 90 секунд)
                long deadline = System.currentTimeMillis() + 90000L;
                boolean stillOn = true;
                while (System.currentTimeMillis() < deadline) {
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException ignored) {
                    }
                    stillOn = isNasOnline();
                    if (!stillOn) {
                        break;
                    }
                }

                final boolean off = !stillOn;
                busy = false;
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        powerButton.setEnabled(true);
                        if (off) {
                            statusView.setText("NAS выключен");
                            hintView.setText("Можно закрывать приложение");
                        } else {
                            statusView.setText("NAS всё ещё включён");
                            hintView.setText("Проверьте веб-интерфейс NAS");
                        }
                    }
                });
            }
        }).start();
    }
}